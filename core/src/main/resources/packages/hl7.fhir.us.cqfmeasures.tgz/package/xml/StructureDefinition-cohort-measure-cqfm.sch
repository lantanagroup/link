<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile CQFMComputableMeasure
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Measure</sch:title>
    <sch:rule context="f:Measure">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-populationBasis']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-populationBasis': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringUnit']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringUnit': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringPrecision']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringPrecision': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:group) &gt;= 1">group: minimum cardinality of 'group' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group</sch:title>
    <sch:rule context="f:Measure/f:group">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-populationBasis']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-populationBasis': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoring']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoring': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringUnit']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringUnit': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringPrecision']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-scoringPrecision': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-compositeScoring']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-compositeScoring': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-riskAdjustment']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-riskAdjustment': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-rateAggregation']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-rateAggregation': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-improvementNotation']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/cqfmeasures/StructureDefinition/cqfm-improvementNotation': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group/f:population</sch:title>
    <sch:rule context="f:Measure/f:group/f:population">
      <sch:assert test="count(f:code) &gt;= 1">code: minimum cardinality of 'code' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
